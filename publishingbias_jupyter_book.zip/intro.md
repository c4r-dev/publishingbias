# Welcome to the Intuition for Publication Bias Book!

This book provides an interactive exploration of publication bias in scientific research.
